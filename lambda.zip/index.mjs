export const handler = async (event) => {
  console.log("sqs start ...............");
  console.log(event);
  console.log("sqs end ............");
};
